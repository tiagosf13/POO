package src.Aula5;

public class Data {
    int day;
    int month;
    int year; 

    //constructor
    Data(int day, int month, int year){
        this.set(day, month, year);
    }
    
    //set date
    public void set(int day, int month, int year){
        if (validDate(day, month, year)==false){
            System.out.println("Data errada!");
            System.exit(0);
        }
        this.day = day;
        this.month = month;
        this.year = year;
    }

    //increment date
    public void incrementDate(int day, int month, int year){
        System.out.println(monthDays(month, year));
        System.out.println(this.day+"/"+this.month+"/"+this.year);
        if(monthDays(this.month, this.year)==this.day){
            if(this.month==12){
                this.day=1;
                this.month=1;
                this.year++; 
            }
            else{
                this.day=1;
                this.month++;
            }
        }
        else{
            this.day++;
        }
    }

    //decrement date
    public void decrementDate(int day, int month, int year){
        if (this.day==1 & this.month==1){
            this.day=31;
            this.month=12;
            this.year--;
        }
        else if (this.day==1){
            this.day=monthDays(month-1, year);
            this.month--;
        }
        else{
            this.day--;
        }
    }

    //devolver a data no formato AAAA-MM-DD
    public String toString(int day, int month, int year){
        String frase = year+"/"+month+"/"+day;
        return(frase);
    }

    //display the date to the user
    public String seeDate(int day, int month, int year){
        String frase;
        frase = ("Data: "+this.day+"/"+this.month+"/"+this.year);
        return (frase);
    }

    //validate month
    public boolean validMonth(int month){
        if (month<1 || month>12){
            return (false);
        }
        else{
            return (true);
        }
    }

    //get monthdays
    public static Integer monthDays(int month, int year){
        if ((leapYear(year)==true) & month==2){
            return(29);
        }
        else{
            if (month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12){
                return(31);
            }
            else{
                if (month==2){
                    return(28);
                }
                else{
                    return(30);
                }
            }
        }
    }

    //verify if the year is a leapYear
    public static boolean leapYear(int year){
        int ano=year;
        boolean isBis;
        if (ano % 400 == 0){
            isBis = true;
        } 
        else if (ano % 100 == 0){
            isBis = false;
        }

        if (ano % 4 == 0) {
            isBis = true;
        } 
        else{
            isBis = false;
        }
        return (isBis);
    }

    //validate the date
    public boolean validDate(int day, int month, int year){
        if (day<=0 || day>31){
            return (false);
        }
        else if(month==2 & day>monthDays(month, year)){
            return (false);
        }
        else if (validMonth(month)==false){
            return (false);
        }
        else{
            return (true);
        }
    }
}